import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';

function App() {
  return (
    <div className="App">
      <Counter></Counter>
      <LoadComments></LoadComments>
    </div>
  );
}

function LoadComments(){
  const [comments, SetComments] = useState([]);
  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/comments')
    .then(res => res.json())
    .then(data => SetComments(data))
  },[])
  return(
    <div>
      <h3>Load Comments:</h3>
      {
        comments.map(comment => <Comment title={comment.name} body={comment.body}></Comment>)
      }
    </div>
  )
}

function Comment(props){
  return(
    <div>
      <h4>Title {props.title}</h4>
      <p>Body {props.body}</p>
    </div>
  )
}


function Counter(){
  const [count,SetCount] = useState(0);
  const handleIncrease = () => SetCount(count + 1);
  const handleDecrease = () => SetCount(count - 1);

  return(
    <div>
      <h2>Counter: {count}</h2>
      <button onClick={handleIncrease}>Increase</button>
      <button onClick={handleDecrease}>Increase</button>
    </div>
  )
}

export default App;
