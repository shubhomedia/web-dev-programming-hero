import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';

function App() {
  
  return(
    <div className='App'>
      <ExternalUsers></ExternalUsers>
    </div>
  );
}

function ExternalUsers(){
  
  const [users,setUsers] = useState([]);

  useEffect (() => {
    fetch('https://jsonplaceholder.typicode.com/users')
    .then(res => res.json())
    .then(data => setUsers(data))
  },[])
  
  return(
    <div>
      <h3>External Users</h3>
      {
        users.map(user => <User name={user.name} email={user.email}></User>)
      }
    </div>
  )
}
function User(props){
  return(
    <div>
      <h2>name : {props.name}</h2>
      <p>Email : {props.email}</p>
    </div>
  )
}

function Counter(){
  const [count,SetCount] = useState(55);
  const handleIncrease = () => {
    const newCount = count + 1;
    SetCount(newCount);
  }
  return (
    <div>
      <h1>Count : {count}</h1>
      <button onClick={handleIncrease} >Click</button>
    </div>
  )
}
export default App;
