import React from 'react';
import Button from 'react-bootstrap/Button';
const Cards = () => {
    return (
        <div>
            <h1 className="text-center">Hello From Cards</h1>
            <Button variant="warning">Button</Button>
        </div>
    );
};

export default Cards;