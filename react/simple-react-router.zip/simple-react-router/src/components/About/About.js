import React from 'react';

const About = () => {
    return (
        <div>
            <h2>This is About</h2>
        </div>
    );
};

export default About;