import React from 'react';

const Notfound = () => {
    return (
        <div>
            <h2>Not Found</h2>
            <h3>Don't ask me about my page</h3>
        </div>
    );
};

export default Notfound;