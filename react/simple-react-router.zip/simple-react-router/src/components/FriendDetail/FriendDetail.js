import React from 'react';

const FriendDetail = () => {
    return (
        <div>
            <h2>Coming Soon</h2>
        </div>
    );
};

export default FriendDetail;