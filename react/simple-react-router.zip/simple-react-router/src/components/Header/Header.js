import React from 'react';
import { Link, NavLink } from 'react-router-dom';

const Header = () => {
    
    const activeStyle={
            fontWeight: "bold",
            color: "red"
    }

    return (
        <div>
            <NavLink to="/home"
                activeStyle={{
                    fontWeight: "bold",
                    color: "red"
                  }}
            >Home</NavLink>
            <NavLink to="/friends">Friends</NavLink>
            <NavLink to="/about">About</NavLink>
        </div>
    );
};

export default Header;