import logo from './logo.svg';
import './App.css';
import Button from '@mui/material/Button';
import News from './components/News/News';

function App() {
  return (
    <div className="App">
      <News></News>
    </div>
  );
}

export default App;
