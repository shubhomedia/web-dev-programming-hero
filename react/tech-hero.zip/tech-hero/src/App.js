import logo from './logo.svg';
import './App.css';
import MainSection from './components/MainSection/MainSection';
import HeaderSection from './components/HeaderSection/HeaderSection';

function App() {
  return (
    <div>
      <HeaderSection></HeaderSection>
      <MainSection></MainSection>
    </div>
  );
}

export default App;
