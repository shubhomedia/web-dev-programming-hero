const simpledata = [
    
    {
    name: 'Apple',
    industry: 'hardware, software, electronics, information technology, etc',
    employees: 147000,
    annualrevenue: '347 bln',
    logo:'https://i.imgur.com/kDGu9ZG.png',
    totalworth: '2382 bln'
},
{
    name:'Samsung Electronics',
    industry: 'hardware, software, electronics, information technology, etc',
    employees: 147000,
    annualrevenue: '347 bln',
    logo:'https://i.imgur.com/ooaS6xG.png',
    totalworth:' 2211 bln'
},
{
    name:'Alphabet',
    industry: 'esearch and development, software, video games, biotechnology, etc',
    employees: 135000,
    annualrevenue: '220 bln',
    logo:'https://i.imgur.com/1p0qy2e.jpg',
    totalworth: '1874 bln'
},
{
    name:'Microsoft',
    industry: 'software development, hardware, electronics, cloud computing, etc',
    employees: 182000,
    annualrevenue: '161 bln',
    logo:'https://i.imgur.com/UrA7WWv.jpg',
    totalworth: '2211 bln'
},
{
    name:'Amazon Inc',
    industry: 'e-commerce, consumer electronics, digital distribution, cloud computing, etc.',
    employees: 1335000,
    annualrevenue: '443 bln',
    logo:'https://i.imgur.com/PwMKvuc.png',
    totalworth: '1694 bln'
},

{
    name:'Facebook',
    industry: 'Social media, online advertisement.',
    employees: 60654,
    annualrevenue:'85 bln',
    logo:'https://i.imgur.com/uJbMgcC.png',
    totalworth: '982 bln'
},

{
    name:'TSMC',
    industry: 'Semiconductors',
    employees: 85858,
    annualrevenue:'73 bln',
    logo:'https://i.imgur.com/7UsgEQE.png',
    totalworth: '572 bln '
},

{
    name:'Nvidia',
    industry: 'Semiconductors, video games, consumer electronics, computer hardware.',
    employees: 18100,
    annualrevenue:'10 bln',
    logo:'https://i.imgur.com/WmsadD8.png',
    totalworth: '539 bln '
},
{
    name:'Tencent',
    industry: 'Semiconductors',
    employees: 56831,
    annualrevenue:'47 bln',
    logo:'https://i.imgur.com/rDUxQD6.png',
    totalworth: '602 bln'
},

{
    name:'Panasonic',
    industry: 'Electroincs Company',
    employees: 259385,
    annualrevenue:'43 bln',
    logo:'https://i.imgur.com/Z2zf4FE.png',
    totalworth: '200 bln'
},
{
name:'Xiaomi',
industry: 'Electroincs Company',
employees: 22074,
annualrevenue:'73 bln',
logo:'https://i.imgur.com/eaKhrDL.png',
totalworth: '500 bln '
}

]