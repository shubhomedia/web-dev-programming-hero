
const HeaderSection = () => {
       
    return (
        <div className="bg-primary text-center">
            <h1 className="text-white pt-3">Tech Club</h1>
            <h3 className="text-white pb-3">Collection Of Tech Gaint </h3>
            <h5 className="text-white pb-3">Total Budget : $ 500000 </h5>
        </div>
    );
};

export default HeaderSection;