import React from 'react';

const CartSection = (props) => {
    console.log(props);
    const {cart} = props;
    let total = 0;
    

    for (const company of cart){
        total = total + company.employees;
    }
    return (
        <div>
            <h5 className="text-center">Company Summary</h5>
            <h5>Total Employee : {props.cart.length}</h5>
            <p>Name:</p>
            <p>Total: {total}</p>

        </div>
    );
};

export default CartSection;