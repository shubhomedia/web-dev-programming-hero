import React, { useEffect, useState } from 'react';
import CartSection from '../CartSection/CartSection';
import Company from '../Company/Company';

const MainSection = () => {

    const [company,setCompany] = useState([]);
    const [cart, setCart] = useState([]);

    useEffect( ()=> {
        fetch('./data.json')
        .then(res => res.json())
        .then(data => setCompany(data));
    } ,[]);

    const handleAddToCart = (company) => {
        const newCart = [...cart, company];
        setCart(newCart);
    }

    return (
        <div className="container">
            <div className="row">
                <div className="col-10">
                    <h3>Company : {company.length}</h3>
                    <div className="">
                        <div className="row row-cols-1 row-cols-md-3 g-4">
                        {
                        company.map(company => <Company 
                            key = {company.key}
                            company={company}
                            handleAddToCart={handleAddToCart}
                        ></Company>)}
                        </div>
                    
                    </div>
                    
                </div>
                <div className="col-2">
                    <CartSection
                        cart={cart}
                    ></CartSection>
                </div>
            </div>
            
        </div>
    );
};

export default MainSection;