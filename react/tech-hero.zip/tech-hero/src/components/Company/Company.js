import React from 'react';
import './Company.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShoppingCart } from '@fortawesome/free-solid-svg-icons';

const Company = (props) => {
    const {name,industry,employees, annualrevenue,logo,totalworth} = props.company;
    const element = <FontAwesomeIcon icon={faShoppingCart} />
    return (
        <div>
            <div class="">
                <div className="col">
                    <div className="card h-100">
                    <div className="card-body">
                        <h5 className="card-title">{name}</h5>
                        <img className="logo-part" src={logo} alt="" />
                        <p className="card-text">Industry  : {industry}</p>
                        <h5>Employee : {employees}</h5>
                        <h5>Annual Revenue : {annualrevenue}</h5>
                        <h5>Net Worth: {totalworth}</h5>
                        <a onClick={() => props.handleAddToCart(props.company)} className="btn btn-primary "> {element} Add to Cart</a>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Company;