import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';

function App() {
  return (
    <div className="App">
      <LoadUsers></LoadUsers>
      <article className="blog">
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Reiciendis vel harum cupiditate aliquid sit culpa nulla minima porro dolore beatae.
      </article>
      <Blog heading="heading1" author = "jamal"></Blog>
      <Blog heading="heading2" author = "kamla"></Blog>
      <Blog heading="heading3" author = "rahim"></Blog>
    </div>
  );
}

function Blog(props){
  const [points, setPoints] = useState(1);
  const clickhandle = () => {
    const newPoints = points * 2;
    setPoints (newPoints);
  }
  return (
    <div>
      <h2>Heading : {props.heading}</h2>
      <h3>Author : {props.author}</h3>
      <h4>Hello Point {points}</h4>
      <button onClick={clickhandle}>Battery Down</button>
    </div>
  );
}

function LoadUsers(){
  const [users,setUsers] = useState([]);

  useEffect(()=>{
    fetch('https://jsonplaceholder.typicode.com/users')
    .then(res => res.json())
    .then(data => setUsers(data))
  },[])

  return (
    <div>
      <h1>Users Loaded: {users.length}</h1>
      {
        users.map(user =><User name={user.name} phone={user.phone}></User>)
      }
    </div>
  )

}

function User(props){
  return(
    <div>
      <h2>Name : {props.name}</h2>
      <h2>Call : {props.phone}</h2>
    </div>
  );
}
export default App;
