export function add(num1,num2){
    return num1 + num2;
}

export function multiply(num1,num2){
    return num1 * num2;
}

function substract(num1,num2){
    return num1 - num2;
}