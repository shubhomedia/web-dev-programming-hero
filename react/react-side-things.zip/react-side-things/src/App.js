import logo from './logo.svg';
import './App.css';
import Cosmetics from './components/Cosmetics/Cosmetics';

function App() {
  return (
    <div className="App">
      <Cosmetics></Cosmetics>
    </div>
  );
}

export default App;
