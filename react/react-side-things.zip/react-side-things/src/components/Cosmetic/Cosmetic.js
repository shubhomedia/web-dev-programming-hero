import React from 'react';
import { addToDb, deleteFromDb } from '../../utilities/fakedb';

const Cosmetic = (props) => {
    console.log(props.cosmetic);
    const {id,first_name,price} = props.cosmetic;
    const handlebuy = id => {
        // set to local storage
        console.log(id);
        addToDb(id);
    }
    const handleRemove = id => {
        deleteFromDb(id);
    }
    return (
        <div>
            <p>ID : {id}</p>
            <h2>Name: {first_name}</h2>
            <h4>Price: $ {price}</h4>
            <button onClick={() => handlebuy(id)}>Buy</button>
            <button onClick={() => handleRemove(id)}>Remove</button>

        </div>
    );
};

export default Cosmetic;