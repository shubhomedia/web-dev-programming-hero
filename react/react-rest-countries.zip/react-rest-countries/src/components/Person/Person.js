import React from 'react';

const Person = () => {
    return (
        <div>
            <h2>This is Person Component</h2>
        </div>
    );
};

export default Person;