import React from 'react';
import img from '../../images/giphy.gif';

const OrderPlaced = () => {
    return (
        <div>
            <img src={img} alt="" />
        </div>
    );
};

export default OrderPlaced;