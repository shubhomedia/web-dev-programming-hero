const firebaseConfig = {
    apiKey: "AIzaSyAWKMZvDrX7cMUis8B6NWqMCihjVBKN9G0",
    authDomain: "ema-john-simple-82f2e.firebaseapp.com",
    projectId: "ema-john-simple-82f2e",
    storageBucket: "ema-john-simple-82f2e.appspot.com",
    messagingSenderId: "687769318736",
    appId: "1:687769318736:web:5896c8de777a1d7b0e6855"
};

export default firebaseConfig;